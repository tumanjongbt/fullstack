## With this assignment, we're providing you the file structure necessary for you to repeat for the rest of the CSS assignments. Note: This does not apply to the Algorithm assignments.  
#### The structure is always like this...
- index.html
- style.css
#### or if images are given to you
- images/
    - name_of_image1.png
    - name_of_image2.png
    - etc. etc.
- index.html
- style.css