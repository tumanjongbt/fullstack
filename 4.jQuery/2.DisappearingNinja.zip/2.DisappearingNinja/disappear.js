$(document).ready(function(){

    $('.ninja1').click(function(){
        $('.ninja1').hide("slow");
    });

    $('.ninja2').click(function(){
        $('.ninja2').hide("slow");
    });

    $('.ninja3').click(function(){
        $('.ninja3').hide("slow");
    });
    
    $('.ninja4').click(function(){
        $('.ninja4').hide("slow");
    });

    $('.ninja5').click(function(){
        $('.ninja5').hide("slow");
    });

    $('.ninja6').click(function(){
        $('.ninja6').hide("slow");
    });

    $('.ninja7').click(function(){
        $('.ninja7').hide("slow");
    });

    $('.ninja8').click(function(){
        $('.ninja8').hide("slow");
    });

    $('#appear').click(function(){
        $('.ninja div').show();
    });

});