$(document).ready(function(){

    $('.image1').click(function(){
        var catImage = $(this).attr('alt-src');
        $(this).attr('src', catImage);
    });

    $('.image2').click(function(e){
        var catImage = $(this).attr('alt-src');
        $(this).attr('src', catImage);
    });

    $('.image3').click(function(e){
        var catImage = $(this).attr('alt-src');
        $(this).attr('src', catImage);
    });

    $('.image4').click(function(e){
        var catImage = $(this).attr('alt-src');
        $(this).attr('src', catImage);
    });

    $('.image5').click(function(e){
        var catImage = $(this).attr('alt-src');
        $(this).attr('src', catImage);
    });

});